export function Home(){
    return (
    <div className="text-center">
        <h1>Welcome to the <span style={{ color: 'blue' }}>ShoppingWeb</span></h1>
        <h3><span style={{ color: 'green' }}>Please enter Store page</span> to go shopping</h3>
        <h3><span style={{ color: 'red' }}>Please enter Checkout page</span> to process checkout</h3>
    </div>
    )
}